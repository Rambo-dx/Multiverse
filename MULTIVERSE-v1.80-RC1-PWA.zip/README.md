# MULTIVERSE Companion — v1.80 RC1

PWA estática lista para GitHub Pages.

## Publicación
1. Sube el contenido de esta carpeta a la rama `main`.
2. En GitHub: **Settings → Pages → Deploy from a branch → main / root**.
3. Abre la URL HTTPS publicada.

La app usa `localStorage` para el estado local y ofrece respaldos JSON desde **⚙ Datos y respaldo**.
